import Schema from "../schema";
import DbObject, { DbObjectConstructorArgs } from "./db-object";

/** @ignore */
export interface FunctiontConstructorArgs extends DbObjectConstructorArgs {
  oid: number;
  schema: Schema;
}

/**
 * Class which represent a PostgreSQL ({@link Function function}.
 * Provides attributes and methods for details of the function.
 * Class name is `Func` instead of `Function`, because `Function` is a reserved word in JavaScript,
 * and cannot be used as a class name.
 */
export default abstract class Func extends DbObject {
  /** @ignore */
  public constructor(args: FunctiontConstructorArgs) {
    super(args);
    this.oid = args.oid;
    this.schema = args.schema;
  }

  /** Object identifier for the {@link Entity} */
  public readonly oid: number;

  /** [[Schema]] of the object. */
  public readonly schema: Schema;

  /**
   * Full name of the object with '.' notation including [[Schema]] name.
   *
   * @example
   * const fullName = entity.fullName; // public.member
   */
  public get fullName(): string {
    return `${this.schema.name}.${this.name}`;
  }
}
