import pgStructure from "./index";

async function demo() {
  const db = await pgStructure({ database: "sil", user: "user", password: "password" });

  const schema = db.schemas.get("public"); // TypeScript: db.get("account") as Entity
  console.log(schema.normalFunctions.map((f) => f.name));
  console.log(db.types.map((t) => `${t.oid} ${t.schema.name} ${t.name}`));
  // console.log(db._systemSchema.types.map((t) => `${t.oid} ${t.schema.name} ${t.name}`));
}

demo();
